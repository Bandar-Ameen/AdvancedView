package com.astooltech.advancedview.finaldemo;

public interface showStause {
    void setStatuse(String statusemess);
}

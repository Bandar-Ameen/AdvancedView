package com.astooltech.advancedview.proteus.autoimageslider.IndicatorView.animation.data;

public interface Value {/*empty*/}

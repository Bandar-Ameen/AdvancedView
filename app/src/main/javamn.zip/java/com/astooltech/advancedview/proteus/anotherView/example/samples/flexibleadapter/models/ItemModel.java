package com.astooltech.advancedview.proteus.anotherView.example.samples.flexibleadapter.models;

/**
 * Model item for ItemHolder.
 *
 * @author Davide Steduto
 * @since 19/10/2016
 */
public class ItemModel extends AbstractModel {

    public ItemModel(String id) {
        super(id);
    }

}
package com.astooltech.advancedview.finaldemo;

public interface showlogin {
    void loadfinshed();
    void onerror(String mess,Object ob);
    void OnRetray();
    void loadmainActivity();

}

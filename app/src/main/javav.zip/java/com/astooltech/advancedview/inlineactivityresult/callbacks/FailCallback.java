package com.astooltech.advancedview.inlineactivityresult.callbacks;


import com.astooltech.advancedview.inlineactivityresult.Result;

public interface FailCallback {
    void onFailed(Result result);
}

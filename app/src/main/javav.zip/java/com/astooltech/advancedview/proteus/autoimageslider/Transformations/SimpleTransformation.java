package com.astooltech.advancedview.proteus.autoimageslider.Transformations;

import android.view.View;

import com.astooltech.advancedview.proteus.autoimageslider.SliderPager;

public class SimpleTransformation implements SliderPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}
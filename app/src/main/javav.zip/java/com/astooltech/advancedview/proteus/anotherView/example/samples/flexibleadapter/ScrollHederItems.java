package com.astooltech.advancedview.proteus.anotherView.example.samples.flexibleadapter;

public class ScrollHederItems {
    public String getSrolitem() {
        return srolitem;
    }

    public void setSrolitem(String srolitem) {
        this.srolitem = srolitem;
    }

    public String getScrolitemtit() {
        return scrolitemtit;
    }

    public void setScrolitemtit(String scrolitemtit) {
        this.scrolitemtit = scrolitemtit;
    }

    private String srolitem;
    private  String scrolitemtit;

}

package com.astooltech.advancedview.proteus.anotherView.example.samples.flexibleadapter;

public class bodyHedaer {

    private String bodytitle;

    public String getBodytitle() {
        return bodytitle;
    }

    public void setBodytitle(String bodytitle) {
        this.bodytitle = bodytitle;
    }

    public String getAnother() {
        return another;
    }

    public void setAnother(String another) {
        this.another = another;
    }

    private String another;
}

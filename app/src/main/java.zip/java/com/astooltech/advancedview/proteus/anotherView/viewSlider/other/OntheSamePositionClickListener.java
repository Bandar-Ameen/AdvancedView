package com.astooltech.advancedview.proteus.anotherView.viewSlider.other;

import androidx.annotation.Keep;

/**
 * @another 江祖赟
 * @date 2017/9/25 0025.
 */
@Keep
public interface OntheSamePositionClickListener {
    void onClickTheSamePosition(int position);
}

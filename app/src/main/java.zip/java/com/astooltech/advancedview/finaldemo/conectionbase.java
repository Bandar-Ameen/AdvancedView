package com.astooltech.advancedview.finaldemo;

public class conectionbase {
    public static String baseurl="BaseUrl";
    public static String Companyname="CompanyName";
    public static String Backage="UrlInstall";
    public static String Verstion="Version";
    public static String urlonly="Url";
    public static String user="/admin3/user.json";
    public static String layout="Layout";
    public static String layouts="Layouts";
    public static String Styles="styles";
    public static String Alayout="Layout";
    public static String Alayouts="Layouts";
    public static String AStyles="styles";
    public static String menuItem="menuitem";
    public static String SettingUrl="SettingUrl";
    public static String dat="uuaarrlllldata";
    public static String firstTime="firsttime";
    public static String Urltyp="UrlType";
    public static String loginn="Login";
    public static String loginnurl="#";
    public static String fir="https://aastol-88ea5-default-rtdb.firebaseio.com/Settings.json";

}

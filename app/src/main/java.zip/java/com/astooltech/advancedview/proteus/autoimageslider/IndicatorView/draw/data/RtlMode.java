package com.astooltech.advancedview.proteus.autoimageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}
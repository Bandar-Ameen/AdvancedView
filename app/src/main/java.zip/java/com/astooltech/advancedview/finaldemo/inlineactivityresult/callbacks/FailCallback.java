package com.astooltech.advancedview.finaldemo.inlineactivityresult.callbacks;


import com.astooltech.advancedview.finaldemo.inlineactivityresult.Result;

public interface FailCallback {
    void onFailed(Result result);
}

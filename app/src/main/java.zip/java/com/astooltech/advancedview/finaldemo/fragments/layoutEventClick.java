package com.astooltech.advancedview.finaldemo.fragments;

public interface layoutEventClick {
    void A_showError_Layout(String message);
    void A_showView_layout();

}
